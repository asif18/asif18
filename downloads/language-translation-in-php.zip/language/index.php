<?php
include 'library.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $lang["login"]; ?></title>
</head>

<body>
<h1><?php echo $lang["welcome"]; ?></h1>
<p><?php echo $lang["this page's language will be dynamically changed. open the library file and change the session value to see the language translation"]; ?></p>
</body>
</html>
