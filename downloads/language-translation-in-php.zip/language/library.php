<?php
session_start();
$_SESSION["language"] = "ar"; // change these value to "en" to translate the page inti english
if(isset($_SESSION["language"]) && $_SESSION["language"] != ""){
	$language = $_SESSION["language"];
	include "lang/$language/$language.php";
}
?>