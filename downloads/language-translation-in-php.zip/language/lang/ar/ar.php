<?php
$lang = array(
"welcome"		=> "ترحيب",
"login"			=> "دخول",
"this page's language will be dynamically changed. open the library file and change the session value to see the language translation"	=> "سيتم تغيير حيوي لغة هذه الصفحة. فتح ملف المكتبة وتغيير قيمة الدورة لرؤية الترجمة"
);
?>