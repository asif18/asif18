<?php
$lang = array(
"welcome"		=> "welcome",
"login"			=> "login",
"this page's language will be dynamically changed. open the library file and change the session value to see the language translation"	=> "this page's language will be dynamically changed. open the library file and chage the session value to see the language translation"
);
?>