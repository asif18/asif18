<?php
function Send_Mail($to,$subject,$body, $reply_to){
require 'class.phpmailer.php';
$from = "anyname@yourdomain.com";
$mail = new PHPMailer();
$mail->IsSMTP(true); // SMTP
$mail->IsHTML(true); // send as HTML
$mail->SMTPAuth   = true;  // SMTP authentication
$mail->Mailer = "smtp";
$mail->Host       = "smtpout.secureserver.net"; // Host here is used my godaady host
$mail->Port       = 80;                    // set the SMTP port
$mail->Username   = "anyname@yourdomain.com";  // set any email
$mail->Password   = "*********";  // set the password
$mail->SetFrom($from, 'From Asif18');
$mail->AddReplyTo($reply_to,'Asif18');
$mail->Subject = $subject;
$mail->MsgHTML($body);
$address = $to;
$mail->AddAddress($address, $to);

	if(!$mail->Send()){
		echo 0;
	}
	else{
		echo 1;
	}

}
$to 		= "mohamedasif18@gmail.com";
$subject = "Test Mail Subject";
$body 	= "Hi<br/>guyz<br/>My fav Choco is Snickers"; // HTML  tags
$mail		= Send_Mail($to,$subject,$body);
echo $mail;
?>